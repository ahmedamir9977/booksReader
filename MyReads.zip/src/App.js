import "./App.css";
import { useState, useEffect } from "react";
import { Link, Route, Routes } from "react-router-dom";

import Shelf from "./Components/Shelf";
import * as BooksAPI from "./BooksAPI";
import Search from "./Components/Search";

function App() {
  const shelf = [
    {
      id: "currentlyReading",
      title: "Currently Reading",
      updated: false,
    },
    {
      id: "wantToRead",
      title: "Want To Read",
      updated: false,
    },
    {
      id: "read",
      title: "Read",
      updated: false,
    },
  ];

  const [booksState, setBooks] = useState([]);
  const [shelvesState, setShelvesState] = useState(shelf);

  const getBooks = async () => {
    const res = await BooksAPI.getAll();
    setBooks(res);
  };

  useEffect(() => {
    getBooks();
  }, []);

  const changeShelf = (book, shelf) => {
    BooksAPI.update(book, shelf);
    setShelvesState((shelvesState) => {
      const newShelveState = shelvesState.map((sh) => {
        if (
          sh.id.toLowerCase() === shelf.toLowerCase() &&
          sh.updated === false
        ) {
          sh.updated = true;
          getBooks();
        } else {
          sh.updated = false;
          getBooks();
        }
        return sh;
      });
      return newShelveState;
    });
  };
  return (
    <Routes>
      <Route
        path="/"
        exact
        element={
          <div className="app">
            <div className="list-books">
              <div className="list-books-title">
                <h1>MyReads</h1>
              </div>
              <div className="list-books-content">
                <div>
                  {shelvesState.map((shelf) => {
                    return (
                      <Shelf
                        key={shelf.id}
                        shelfId={shelf.id}
                        title={shelf.title}
                        books={booksState.filter((book) => {
                          return book.shelf === shelf.id;
                        })}
                        changeShelf={changeShelf}
                      />
                    );
                  })}
                </div>
              </div>
              <div className="open-search">
                <Link to="/search">Add a book</Link>
              </div>
            </div>
          </div>
        }
      />
      <Route
        path="/search"
        exact
        element={
          <Search changeShelf={changeShelf} booksCategorized={booksState} />
        }
      />
    </Routes>
  );
}

export default App;
