import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import Book from "../Components/Book";
import * as BooksAPI from "../BooksAPI";

const Search = ({ changeShelf, booksCategorized }) => {
  const [searchQuery, setSearchQuery] = useState(" ");
  const [books, setBooks] = useState([]);

  const updateQuery = (query) => {
    setSearchQuery(query);
  };

  const getBooks = async (query) => {
    const res = await BooksAPI.search(query === "" ? " " : query);
    if (res.error === "empty query") {
      setBooks([]);
    } else {
      setBooks(res);
    }
  };

  useEffect(() => {
    getBooks(searchQuery);
  }, [searchQuery]);

  return (
    <div className="search-books">
      <div className="search-books-bar">
        <Link to="/" className="close-search">
          Close
        </Link>
        <div className="search-books-input-wrapper">
          <input
            onChange={(event) => {
              updateQuery(event.target.value);
            }}
            type="text"
            placeholder="Search by title, author, or ISBN"
          />
        </div>
      </div>
      <div className="search-books-results">
        <ol className="books-grid">
          {books &&
            books.map((sBook) => {
              return (
                <li key={sBook.id}>
                  <Book
                    currentBook={sBook}
                    bookTitle={sBook.title}
                    bookAuthor={sBook.authors}
                    bookCover={sBook.imageLinks}
                    changeShelf={changeShelf}
                    currentShelf={booksCategorized
                      .filter((storedBook) => {
                        if (sBook.id === storedBook.id) {
                          return storedBook;
                        }
                      })
                      .map((shelf) => {
                        return shelf.shelf;
                      })}
                  />
                </li>
              );
            })}
        </ol>
      </div>
    </div>
  );
};

export default Search;
