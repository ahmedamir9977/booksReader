import Book from "./Book";

const Shelf = ({ title, books, shelfId, changeShelf }) => {
  return (
    <div className="bookshelf">
      <h2 className="bookshelf-title">{title}</h2>
      <div className="bookshelf-books">
        <ol className="books-grid">
          {books.map((book) => {
            return (
              <li key={book.id}>
                <Book
                  currentBook={book}
                  bookTitle={book.title}
                  bookAuthor={book.authors}
                  bookCover={book.imageLinks}
                  currentShelf={shelfId}
                  changeShelf={changeShelf}
                />
              </li>
            );
          })}
        </ol>
      </div>
    </div>
  );
};
export default Shelf;
